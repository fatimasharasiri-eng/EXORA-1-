"""EXORA – main Streamlit app.

Run with:   python -m streamlit run streamapp.py

All the page logic comes from the files your team wrote (log_in, account, ai,
map, ar, home). They are combined here as one app so the new design (splash,
onboarding, floating navigation bar) can sit around them. The classes in
./classes are used exactly as written.

Flow:
  splash -> onb1 -> onb2 -> onb3 -> home (guest)  or  welcome -> login / signup
  signup -> verify_email -> account_created -> home
  login -> forgot -> reset_code -> reset_new -> reset_done -> login
  home <-> map / ar / account   (floating bar)      home -> chat (assistant orb)
"""
import base64
import html
import secrets
import time
from pathlib import Path

import streamlit as st
from PIL import Image

from classes.authentication import Authentication
from classes.language_manager import LanguageManager
from ui_text import EXTRA, MESSAGE_KEYS

BASE = Path(__file__).parent
IMG = BASE / "images"

st.set_page_config(
    page_title="EXORA",
    page_icon="🧭",
    layout="wide",
    initial_sidebar_state="collapsed",
)

# ----------------------------------------------------------------------
# Where the buttons lead (change these to re-wire the flow)
# ----------------------------------------------------------------------
AFTER_SPLASH = "onb1"
AFTER_ONBOARDING = "home"        # "ابدأ الاستكشاف" on the last onboarding screen
AFTER_LOGIN = "home"
SKIP_TARGET = "welcome"          # "تخطي" on onboarding

AUTH_PAGES = ("welcome", "login", "signup", "verify_email", "account_created",
              "forgot", "reset_code", "reset_new", "reset_done")
FLOW_PAGES = ("splash", "onb1", "onb2", "onb3") + AUTH_PAGES
DOCK_PAGES = ("home", "map", "ar", "account")

LANGUAGES = {"العربية 🇸🇦": "ar", "English 🇬🇧": "en", "Français 🇫🇷": "fr"}
CODE_LIFETIME = 300  # seconds a sign-up verification code stays valid

# ----------------------------------------------------------------------
# Session state (same names the original files use)
# ----------------------------------------------------------------------
for _key, _default in {
    "page": "splash",
    "language": "ar",
    "logged_in": False,
    "current_user": None,
    "messages": [],
    "onb_chip": "all",
}.items():
    st.session_state.setdefault(_key, _default)


@st.cache_resource
def get_auth() -> Authentication:
    """One Authentication object shared by every visitor (kept while the server runs)."""
    return Authentication()


auth = get_auth()
st.session_state.auth = auth   # account.py reads st.session_state.auth

language = LanguageManager(st.session_state.language)


def t(key: str, **values) -> str:
    """Translate: LanguageManager first, then ui_text.EXTRA, then English."""
    text = language.get_text(key)
    if text == key:
        lang_code = language.get_current_language()
        text = EXTRA.get(lang_code, {}).get(key) or EXTRA["en"].get(key, key)
    return text.format(**values) if values else text


def tm(message: str) -> str:
    """Translate an English message returned by the Authentication class."""
    return t(MESSAGE_KEYS.get(message, message))


def is_rtl() -> bool:
    return language.get_direction() == "rtl"


# ----------------------------------------------------------------------
# Assets + CSS
# ----------------------------------------------------------------------
IMAGES = {
    "flower": "flower.jpg",
    "innovation": "innovation.jpg",
    "art": "interactive-art.jpg",
    "orb": "assistant-orb.jpg",
}


@st.cache_data
def data_uri(path: str) -> str:
    p = Path(path)
    mime = "image/png" if p.suffix.lower() == ".png" else "image/jpeg"
    return f"data:{mime};base64,{base64.b64encode(p.read_bytes()).decode()}"


def logo_html(name: str = "logo.png") -> str:
    return f'<div class="brand"><img src="{data_uri(str(IMG / name))}" alt="EXORA"></div>'


def inject_css(page: str) -> None:
    css = (BASE / "exora.css").read_text(encoding="utf-8")
    variables = ":root{" + "".join(
        f'--img-{name}:url("{data_uri(str(IMG / file))}");'
        for name, file in IMAGES.items()
        if (IMG / file).exists()
    ) + f"--dir:{language.get_direction()};}}"
    st.markdown(f"<style>{css}\n{variables}</style>", unsafe_allow_html=True)
    # one class per page so the stylesheet can target each screen
    st.markdown(
        f"<style>.stApp{{--page:'{page}';}}</style>"
        f'<div class="page-marker page-{page}"></div>',
        unsafe_allow_html=True,
    )


# ----------------------------------------------------------------------
# Small helpers
# ----------------------------------------------------------------------
def go(page: str) -> None:
    st.session_state.page = page


def flash(message: str) -> None:
    st.session_state.flash = message


def set_language(widget_key: str) -> None:
    st.session_state.language = LANGUAGES[st.session_state[widget_key]]


def language_selector(widget_key: str, collapsed: bool = False) -> None:
    labels = list(LANGUAGES)
    current = next(k for k, v in LANGUAGES.items() if v == st.session_state.language)
    st.selectbox(
        "Language / اللغة / Langue",
        labels,
        index=labels.index(current),
        key=widget_key,
        label_visibility="collapsed" if collapsed else "visible",
        on_change=set_language,
        args=(widget_key,),
    )


def new_code() -> str:
    return "".join(secrets.choice("0123456789") for _ in range(6))


def back_arrow() -> str:
    return "›" if is_rtl() else "‹"


def forward_arrow() -> str:
    return "←" if is_rtl() else "→"


def topbar(back_to: str | None = None, show_logo: bool = True) -> None:
    """Back button (start side) + centred logo. Used by every auth screen."""
    back_col, logo_col, end_col = st.columns([1, 3, 1], vertical_alignment="center")
    with back_col:
        if back_to:
            st.button(back_arrow(), key="back_btn", on_click=go, args=(back_to,))
    with logo_col:
        if show_logo:
            st.markdown(logo_html(), unsafe_allow_html=True)


def screen_title(title: str, subtitle: str = "", strong: str = "") -> None:
    extra = f"<strong dir='ltr'>{html.escape(strong)}</strong>" if strong else ""
    st.markdown(
        f'<h1 class="title">{title}</h1><p class="subtitle">{subtitle}{extra}</p>',
        unsafe_allow_html=True,
    )


def start_verification(username: str) -> None:
    """Open the e-mail verification step for a freshly registered user."""
    user = auth.users[username]
    st.session_state.verify = {
        "username": username,
        "email": user["email"],
        "code": new_code(),
        "expiry": time.time() + CODE_LIFETIME,
    }
    st.session_state.page = "verify_email"


def cancel_signup() -> None:
    """Go back to the sign-up form and free the half-finished account."""
    pending = st.session_state.pop("verify", None)
    if pending:
        user = auth.users.get(pending["username"])
        if user and not user.get("verified", True):
            del auth.users[pending["username"]]
    st.session_state.page = "signup"


# ======================================================================
# 1. Splash
# ======================================================================
def render_splash() -> None:
    with st.container(key="splash_lang"):
        language_selector("splash_language", collapsed=True)

    st.markdown(
        '<div class="splash"><div class="ring ring--1"></div>'
        '<div class="ring ring--2"></div><div class="ring ring--3"></div>'
        f'<div class="splash__center"><img class="splash__logo" src="{data_uri(str(IMG / "logo.png"))}" alt="EXORA">'
        f'<p class="splash__tagline">{t("splash_tagline")}</p></div></div>',
        unsafe_allow_html=True,
    )
    with st.container(key="splash_bottom"):
        st.markdown('<div class="splash__dash"></div>', unsafe_allow_html=True)
        st.button(f'{t("start_exploring")}  {forward_arrow()}', key="start",
                  on_click=go, args=(AFTER_SPLASH,))


# ======================================================================
# 2. Onboarding (3 screens)
# ======================================================================
PAVILION_CARDS = [  # (title key, meta key, image, tag)
    ("pav_innovation", "meta_tech", "innovation", "tech"),
    ("pav_culture", "meta_culture", "art", "culture"),
]


def set_chip(chip: str) -> None:
    st.session_state.onb_chip = chip


def visual_pavilions() -> None:
    query = st.text_input("search", key="onb_search", placeholder=t("search_pavilions"),
                          label_visibility="collapsed")
    with st.container(key="chips"):
        for chip in ("all", "tech", "culture"):
            st.button(t(f"chip_{chip}"), key=f"chip_{chip}", on_click=set_chip, args=(chip,),
                      type="primary" if st.session_state.onb_chip == chip else "secondary")

    q = query.strip().lower()
    chosen = [
        c for c in PAVILION_CARDS
        if st.session_state.onb_chip in ("all", c[3])
        and (not q or q in t(c[0]).lower() or q in t(c[1]).lower())
    ]
    cards = "".join(
        f'<div class="pcard {"pcard--front" if i == 0 else "pcard--back"}">'
        f'<div class="pcard__img pcard__img--{img}"></div>'
        f'<div class="pcard__title">{t(title)}</div><div class="pcard__meta">{t(meta)}</div></div>'
        for i, (title, meta, img, _tag) in enumerate(chosen)
    )
    st.markdown(f'<div class="pcards">{cards or "<p class=empty>" + t("no_results") + "</p>"}</div>',
                unsafe_allow_html=True)


def visual_map() -> None:
    blocks = "".join(
        f'<i class="map-block" style="{s}"></i>' for s in (
            "left:6%;top:8%", "left:40%;top:30%;width:14%", "left:10%;top:36%;width:15%;height:8%",
            "left:70%;top:60%", "left:44%;top:68%;width:20%", "left:74%;top:6%;width:20%;height:9%")
    ) + "".join(
        f'<i class="map-dot" style="{s}"></i>' for s in (
            "left:18%;top:62%", "left:60%;top:12%", "left:86%;top:42%"))
    st.markdown(
        f'<div class="map-card"><div class="map-card__roads">{blocks}</div>'
        '<svg class="map-route" viewBox="0 0 400 330" xmlns="http://www.w3.org/2000/svg">'
        '<path d="M200 70 C 270 90, 280 140, 240 170 S 150 210, 215 270"/>'
        '<circle class="start" cx="215" cy="270" r="11"/>'
        '<path class="pin" d="M200 40a16 16 0 0 1 16 16c0 12-16 30-16 30s-16-18-16-30a16 16 0 0 1 16-16z"/>'
        '<circle cx="200" cy="56" r="6" fill="#fff"/></svg>'
        f'<span class="map-label">{t("pav_innovation")}</span>'
        '<div class="ar-thumb"><span class="ar-thumb__badge">AR</span>'
        '<div class="ar-thumb__chevrons"><svg width="54" height="54" viewBox="0 0 24 24" fill="none" '
        'stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">'
        '<path d="M6 11l6-6 6 6M6 19l6-6 6 6"/></svg></div></div></div>',
        unsafe_allow_html=True,
    )


def visual_chat() -> None:
    st.markdown(
        '<div class="chat-card">'
        f'<div class="chat-head"><span class="orb"></span>{t("assistant_name")}</div>'
        f'<div class="bubble bubble--user">{t("sample_question")}</div>'
        f'<div class="bubble bubble--bot">{t("sample_answer")}</div>'
        '<div class="mini-card"><div class="mini-card__img"></div><div class="mini-card__body">'
        f'<div class="mini-card__title">{t("pav_innovation")}</div>'
        f'<div class="mini-card__meta">{t("meta_tech")}</div>'
        f'<div class="btn btn--tonal btn--small">{t("view_pavilion")}</div></div></div></div>',
        unsafe_allow_html=True,
    )


ONBOARDING = {
    "onb1": dict(visual=visual_pavilions, title="onb1_title", text="onb1_text",
                 primary="next", primary_to="onb2", prev=None),
    "onb2": dict(visual=visual_map, title="onb2_title", text="onb2_text",
                 primary="next", primary_to="onb3", prev="onb1"),
    "onb3": dict(visual=visual_chat, title="onb3_title", text="onb3_text",
                 primary="start_explore_btn", primary_to=AFTER_ONBOARDING, prev="onb2"),
}


def render_onboarding(page: str) -> None:
    data = ONBOARDING[page]
    index = list(ONBOARDING).index(page)

    _spacer, logo_col, skip_col = st.columns([1, 2, 1], vertical_alignment="center")
    with logo_col:
        st.markdown(logo_html(), unsafe_allow_html=True)
    with skip_col:
        if page != "onb3":
            st.button(t("skip"), key="onb_skip", on_click=go, args=(SKIP_TARGET,))

    text_col, visual_col = st.columns([1, 1.15], gap="large", vertical_alignment="center")
    with text_col:
        dots = "".join(f'<span class="dot{" dot--on" if i == index else ""}"></span>'
                       for i in range(len(ONBOARDING)))
        st.markdown(
            f'<div class="onb__text"><h1 class="onb__title">{t(data["title"])}</h1>'
            f'<p class="onb__desc">{t(data["text"])}</p><div class="dots">{dots}</div></div>',
            unsafe_allow_html=True,
        )
        st.button(t(data["primary"]), key="onb_next", type="primary",
                  on_click=go, args=(data["primary_to"],))
        if data["prev"]:
            st.button(t("previous"), key="onb_prev", on_click=go, args=(data["prev"],))
        if page == "onb3":
            st.button(t("login_or_signup"), key="onb_login", on_click=go, args=("welcome",))
    with visual_col:
        data["visual"]()


# ======================================================================
# 3. Welcome + authentication (logic from log_in.py)
# ======================================================================
GOOGLE_SVG = (
    '<svg width="22" height="22" viewBox="0 0 48 48"><path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 '
    '9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 '
    '9.5 24 9.5z"/><path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 '
    '5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/><path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99'
    '-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/>'
    '<path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22'
    '-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/></svg>'
)
APPLE_SVG = (
    '<svg width="22" height="22" viewBox="0 0 24 24" fill="#1a1535"><path d="M12.152 6.896c-.948 0-2.415-1.078-3.96'
    '-1.04-2.04.027-3.91 1.183-4.961 3.014-2.117 3.675-.546 9.103 1.519 12.09 1.013 1.454 2.208 3.09 3.792 3.039 '
    '1.52-.065 2.09-.987 3.935-.987 1.831 0 2.35.987 3.96.948 1.637-.026 2.676-1.48 3.676-2.948 1.156-1.688 1.636'
    '-3.325 1.662-3.415-.039-.013-3.182-1.221-3.22-4.857-.026-3.04 2.48-4.494 2.597-4.559-1.429-2.09-3.623-2.324'
    '-4.39-2.376-2-.156-3.675 1.09-4.61 1.09zM15.53 3.83c.843-1.012 1.4-2.427 1.245-3.83-1.207.052-2.662.805-3.532 '
    '1.818-.78.896-1.454 2.338-1.273 3.714 1.338.104 2.715-.688 3.559-1.701"/></svg>'
)


def social_row(label_key: str = "or") -> None:
    """Google / Apple are pictures only (no sign-in behind them)."""
    st.markdown(
        f'<div class="divider">{t(label_key)}</div>'
        f'<div class="social" aria-hidden="true"><div class="social__btn">{GOOGLE_SVG}<span>Google</span></div>'
        f'<div class="social__btn">{APPLE_SVG}<span>Apple</span></div></div>',
        unsafe_allow_html=True,
    )


def guest_button() -> None:
    st.button(f'{t("continue_guest")}  {forward_arrow()}', key="guest", on_click=go, args=("home",))


def render_welcome() -> None:
    with st.container(key="auth_card"):
        topbar(back_to="onb3")
        screen_title(t("welcome_title"), t("welcome_sub"))
        st.button(t("login"), key="welcome_login", on_click=go, args=("login",))
        st.button(t("register"), key="welcome_signup", on_click=go, args=("signup",))
        social_row("or_continue_with")
        st.button(t("guest_enter"), key="guest", on_click=go, args=("home",))
        language_selector("welcome_language", collapsed=True)


def render_login() -> None:
    with st.container(key="auth_card"):
        topbar(back_to="welcome")
        screen_title(t("login_title"), t("login_sub"))

        with st.form("login_form", border=False):
            username = st.text_input(t("username"), key="login_username", placeholder=t("username_ph"))
            password = st.text_input(t("password"), type="password", key="login_password",
                                     placeholder="••••••••")
            st.markdown('<div class="form-gap"></div>', unsafe_allow_html=True)
            submitted = st.form_submit_button(t("login"), type="primary", key="login_submit")
        st.button(t("forgot_password"), key="forgot_link", on_click=go, args=("forgot",))

        if submitted:
            username = username.strip()
            if auth.login(username, password):
                user = auth.users[username]
                if user.get("verified", True) is False:      # registered but never confirmed
                    start_verification(username)
                    flash(t("verify_first"))
                else:
                    st.session_state.logged_in = True
                    st.session_state.current_user = username
                    flash(t("welcome_user", name=user.get("name", username)))
                    st.session_state.page = AFTER_LOGIN
                st.rerun()
            else:
                st.error(t("invalid_credentials"))

        social_row()
        st.button(t("no_account"), key="to_signup", on_click=go, args=("signup",))
        guest_button()


def render_signup() -> None:
    with st.container(key="auth_card"):
        topbar(back_to="welcome")
        screen_title(t("signup_title"), t("signup_sub"))

        with st.form("signup_form", border=False):
            name = st.text_input(t("name"), key="signup_name", placeholder=t("name_ph"))
            email = st.text_input(t("email"), key="signup_email", placeholder="name@example.com")
            username = st.text_input(t("username"), key="signup_username",
                                     placeholder=t("choose_username_ph"))
            password = st.text_input(t("password"), type="password", key="signup_password",
                                     placeholder=t("password_ph"))
            st.markdown(f'<div class="field__hint">{t("password_hint")}</div><div class="form-gap"></div>',
                        unsafe_allow_html=True)
            submitted = st.form_submit_button(t("signup_btn"), type="primary", key="signup_submit")

        if submitted:
            email, username, name = email.strip(), username.strip(), name.strip()
            if not name:
                st.warning(t("enter_name"))
            else:
                ok, message = auth.sign_up(email, username, password)
                if ok:
                    auth.users[username]["name"] = name
                    auth.users[username]["verified"] = False
                    start_verification(username)
                    st.rerun()
                elif message in ("Invalid email", "Username already exists", "Email already registered"):
                    st.error(tm(message))
                else:
                    st.warning(tm(message))

        social_row()
        st.button(t("have_account_login"), key="to_login", on_click=go, args=("login",))
        guest_button()


def render_verify_email() -> None:
    pending = st.session_state.get("verify")
    if not pending:
        st.session_state.page = "signup"
        st.rerun()

    with st.container(key="auth_card"):
        st.button(back_arrow(), key="back_btn", on_click=cancel_signup)
        st.markdown(logo_html(), unsafe_allow_html=True)
        screen_title(t("verify_email_title"), t("verify_email_sub"), strong=pending["email"])

        # No e-mail service is connected yet, so the code is shown here (same idea as the demo code).
        st.info(f'{t("demo_code")}: **{pending["code"]}**')

        with st.form("verify_form", border=False):
            code = st.text_input(t("verification_code"), key="verify_code", max_chars=6,
                                 placeholder="— — — — — —", label_visibility="collapsed")
            st.markdown(f'<p class="otp__hint">{t("code_hint")}</p>', unsafe_allow_html=True)
            submitted = st.form_submit_button(t("confirm_email"), type="primary", key="verify_submit")

        if submitted:
            if time.time() > pending["expiry"]:
                st.error(t("code_expired"))
            elif code.strip() != pending["code"]:
                st.error(t("invalid_code"))
            else:
                username = pending["username"]
                auth.users[username]["verified"] = True
                st.session_state.logged_in = True
                st.session_state.current_user = username
                st.session_state.pop("verify", None)
                st.session_state.page = "account_created"
                st.rerun()

        if st.button(t("resend_code"), key="resend_verify"):
            pending["code"], pending["expiry"] = new_code(), time.time() + CODE_LIFETIME
            st.toast(t("code_resent"))
            st.rerun()
        st.button(t("change_email"), key="change_email_verify", on_click=cancel_signup)


def render_account_created() -> None:
    with st.container(key="auth_card"):
        st.markdown(logo_html(), unsafe_allow_html=True)
        screen_title(t("created_title"), t("created_sub"))
        st.markdown('<div class="success-badge">✓</div>', unsafe_allow_html=True)
        st.button(t("start_explore_btn"), key="created_start", type="primary", on_click=go, args=(AFTER_LOGIN,))


# ---- forgot password (3 steps: e-mail -> code -> new password) ----------
def render_forgot() -> None:
    with st.container(key="auth_card"):
        topbar(back_to="login")
        screen_title(t("forgot_title"), t("forgot_sub"))

        with st.form("forgot_form", border=False):
            email = st.text_input(t("email"), key="forgot_email_input", placeholder="name@example.com")
            st.markdown(f'<div class="field__hint">{t("forgot_hint")}</div><div class="form-gap"></div>',
                        unsafe_allow_html=True)
            submitted = st.form_submit_button(t("send_code"), type="primary", key="forgot_submit")
        st.button(t("back_to_login"), key="back_login", on_click=go, args=("login",))

        if submitted:
            email = email.strip()
            success, code = auth.generate_reset_code(email)
            if success:
                st.session_state.reset_email = email
                st.session_state.reset_demo_code = code
                st.session_state.page = "reset_code"
                st.rerun()
            else:
                st.error(t("email_not_found"))


def render_reset_code() -> None:
    email = st.session_state.get("reset_email")
    if not email:
        st.session_state.page = "forgot"
        st.rerun()

    with st.container(key="auth_card"):
        topbar(back_to="forgot")
        screen_title(t("code_title"), t("code_sub"), strong=email)
        st.info(f'{t("demo_code")}: **{st.session_state.get("reset_demo_code", "")}**')

        with st.form("code_form", border=False):
            code = st.text_input(t("verification_code"), key="reset_code_input", max_chars=6,
                                 placeholder="— — — — — —", label_visibility="collapsed")
            st.markdown(f'<p class="otp__hint">{t("code_hint")}</p>', unsafe_allow_html=True)
            submitted = st.form_submit_button(t("verify"), type="primary", key="code_submit")

        if submitted:
            saved = auth.reset_codes.get(email)
            if not saved:
                st.error(t("no_reset_request"))
            elif time.time() > saved["expiry"]:
                st.error(t("code_expired"))
            elif saved["code"] != code.strip():
                st.error(t("invalid_code"))
            else:
                st.session_state.reset_verified_code = code.strip()
                st.session_state.page = "reset_new"
                st.rerun()

        if st.button(t("resend_code"), key="resend_reset"):
            success, new = auth.generate_reset_code(email)
            if success:
                st.session_state.reset_demo_code = new
                st.toast(t("code_resent"))
                st.rerun()
        st.button(t("change_email"), key="change_email_reset", on_click=go, args=("forgot",))


def render_reset_new() -> None:
    email = st.session_state.get("reset_email")
    code = st.session_state.get("reset_verified_code")
    if not email or not code:
        st.session_state.page = "forgot"
        st.rerun()

    with st.container(key="auth_card"):
        topbar(back_to="reset_code")
        screen_title(t("newpw_title"), t("newpw_sub"))

        with st.form("newpw_form", border=False):
            new_password = st.text_input(t("new_password"), type="password", key="reset_new_password",
                                         placeholder="••••••••")
            st.markdown(f'<div class="field__hint">{t("password_hint")}</div>', unsafe_allow_html=True)
            confirm = st.text_input(t("confirm_password"), type="password", key="reset_confirm_password",
                                    placeholder="••••••••")
            st.markdown('<div class="form-gap"></div>', unsafe_allow_html=True)
            submitted = st.form_submit_button(t("save_password"), type="primary", key="newpw_submit")

        if submitted:
            if new_password != confirm:
                st.error(t("passwords_mismatch"))
            else:
                success, message = auth.reset_password(email, code, new_password)
                if success:
                    for k in ("reset_email", "reset_demo_code", "reset_verified_code"):
                        st.session_state.pop(k, None)
                    st.session_state.page = "reset_done"
                    st.rerun()
                else:
                    (st.warning if message.startswith("Password must") else st.error)(tm(message))


def render_reset_done() -> None:
    with st.container(key="auth_card"):
        st.markdown(logo_html(), unsafe_allow_html=True)
        screen_title(t("pwchanged_title"), t("pwchanged_sub"))
        st.markdown('<div class="success-badge">✓</div>', unsafe_allow_html=True)
        st.button(t("pwchanged_btn"), key="reset_done_btn", type="primary", on_click=go, args=("login",))


# ======================================================================
# 4. Home (new design) + floating navigation
# ======================================================================
WINGS = [  # (title key, meta key, image)
    ("pav_innovation", "pav_innovation_meta", "innovation"),
    ("pav_art", "pav_art_meta", "art"),
]


def render_dock(page: str) -> None:
    """Floating bar: home / map / AR, plus the separate account button."""
    with st.container(key="dock"):
        with st.container(key="dock_bar"):
            for key, icon, label in (("home", ":material/home:", t("nav_home")),
                                     ("map", ":material/map:", t("nav_map")),
                                     ("ar", ":material/view_in_ar:", t("nav_ar"))):
                st.button(label, key=f"dock_{key}", icon=icon, on_click=go, args=(key,),
                          type="primary" if page == key else "secondary")
        st.button(t("nav_account"), key="dock_account", icon=":material/person:", on_click=go,
                  args=("account",), type="primary" if page == "account" else "secondary")


def render_home() -> None:
    st.markdown(logo_html(), unsafe_allow_html=True)
    st.markdown(f'<h1 class="home-title">{t("home_title")}</h1><p class="home-sub">{t("home_sub")}</p>',
                unsafe_allow_html=True)
    query = st.text_input("search", key="search", placeholder=t("search_ph"), label_visibility="collapsed")

    with st.container(key="ar_banner"):
        text_col, img_col = st.columns([1.1, 1], gap="small")
        with text_col:
            st.markdown(f'<h2 class="ar-banner__title">{t("ar_banner_title")}</h2>'
                        f'<p class="ar-banner__desc">{t("ar_banner_text")}</p>', unsafe_allow_html=True)
            st.button(f'{t("choose_destination_btn")} {forward_arrow()}', key="ar_cta",
                      on_click=go, args=("ar",))
        with img_col:
            st.markdown('<div class="ar-banner__img"></div>', unsafe_allow_html=True)

    head_col, link_col = st.columns([3, 1], vertical_alignment="center")
    with head_col:
        st.markdown(f'<h2 class="section-head__title">{t("explore_pavilions")}</h2>', unsafe_allow_html=True)
    with link_col:
        st.button(f'{t("view_all")} ›' if is_rtl() else f'{t("view_all")} ›', key="view_all",
                  on_click=go, args=("map",))

    q = query.strip().lower()
    shown = [w for w in WINGS if not q or q in t(w[0]).lower() or q in t(w[1]).lower()]
    if not shown:
        st.markdown(f'<p class="empty">{t("no_results")}</p>', unsafe_allow_html=True)
    else:
        cols = st.columns(2, gap="large")
        for col, (title, meta, img) in zip(cols, shown):
            with col, st.container(key=f"wing_{img}"):
                st.markdown(
                    f'<div class="wing-card__img wing-card__img--{img}"></div>'
                    f'<h3 class="wing-card__title">{t(title)}</h3><p class="wing-card__meta">{t(meta)}</p>',
                    unsafe_allow_html=True)
                st.button(f'{t("discover_experience")} ‹' if is_rtl() else f'{t("discover_experience")} ›',
                          key=f"wing_btn_{img}", type="primary", on_click=go, args=("map",))

    with st.container(key="assistant"):
        st.button(t("open_assistant"), key="orb", on_click=go, args=("chat",))
        st.markdown(f'<div class="assistant__bubble">{t("assistant_bubble")}</div>', unsafe_allow_html=True)


# ======================================================================
# 5. Chat (logic from ai.py)
# ======================================================================
def load_avatar():
    own = BASE / "assets" / "exora.jpg"
    return Image.open(own if own.exists() else IMG / "assistant-orb.jpg")


def render_chat() -> None:
    from classes.chatbot import get_response

    assistant_avatar = load_avatar()

    top_col, _mid, clear_col = st.columns([1, 4, 1], vertical_alignment="center")
    with top_col:
        st.button(back_arrow(), key="back_btn", on_click=go, args=("home",))
    with clear_col:
        if st.button(t("clear_chat"), key="clear_chat"):
            st.session_state.messages = []
            st.rerun()

    st.markdown(f'<h1 class="title">{t("chat_title")}</h1><p class="subtitle">{t("chat_sub")}</p>',
                unsafe_allow_html=True)
    st.divider()

    if not st.session_state.messages:
        with st.chat_message("assistant", avatar=assistant_avatar):
            st.markdown(t("chat_welcome"))

    for message in st.session_state.messages:
        avatar = assistant_avatar if message["role"] == "assistant" else "user"
        with st.chat_message(message["role"], avatar=avatar):
            st.markdown(message["content"])

    user_input = st.chat_input(t("chat_placeholder"))
    if user_input:
        with st.chat_message("user", avatar="user"):
            st.markdown(user_input)

        history = st.session_state.messages.copy()
        st.session_state.messages.append({"role": "user", "content": user_input})

        with st.chat_message("assistant", avatar=assistant_avatar):
            with st.spinner(t("chat_thinking")):
                try:
                    answer = get_response(user_input, history)
                    st.markdown(answer)
                    st.session_state.messages.append({"role": "assistant", "content": answer})
                except Exception as e:
                    st.error(t("chat_error"))
                    st.caption(f'{t("chat_error_details")}: {e}')


# ======================================================================
# 6. Map (logic from map.py)
# ======================================================================
def render_map() -> None:
    try:
        from classes.corridor_crowd import CrowdManager
        from classes.Route_Manager import RouteManager
        from classes.MapManager import MapManager
    except ImportError as e:
        st.error(t("missing_classes", name=str(e)))
        return

    try:
        crowd_manager = CrowdManager()
        route_manager = RouteManager(crowd_manager)
    except FileNotFoundError as e:
        st.error(t("missing_data", name=e.filename or str(e)))
        return
    route_manager.build_graph()
    map_manager = MapManager(crowd_manager, route_manager)

    st.markdown(f'<h1 class="title title--start">{t("map_title")}</h1>', unsafe_allow_html=True)

    scenario = st.selectbox(t("crowd_scenario"), list(crowd_manager.SCENARIOS.keys()))
    crowd_manager.set_crowd_scenario(scenario)

    locations = list(route_manager.graph.nodes)
    start = st.selectbox(t("start_label"), locations)
    destination = st.selectbox(t("destination_label"), [n for n in locations if n != start])

    if st.button(t("find_route"), key="map_find", type="primary"):
        route_result = route_manager.find_route(start, destination)

        if route_result.get("route"):
            route = route_result["route"]
            crowd_rates = [crowd_manager.get_crowd_rate(route[i], route[i + 1])
                           for i in range(len(route) - 1)]
            if crowd_rates:
                average_crowd = (sum(crowd_rates) / len(crowd_rates)) * 100
                if average_crowd < 40:
                    crowd_level, crowd_icon = t("crowd_low"), "🟢"
                elif average_crowd < 75:
                    crowd_level, crowd_icon = t("crowd_medium"), "🟡"
                else:
                    crowd_level, crowd_icon = t("crowd_high"), "🔴"
                st.metric(label=t("route_crowd_level"), value=f"{crowd_icon} {crowd_level}",
                          delta=t("occupancy", pct=f"{average_crowd:.1f}"))

            map_manager.render(route_result=route_result, start=start, destination=destination)

            st.success(f'{t("recommended_route")}: ' + " → ".join(route_result["route"]))
            st.write(f'{t("route_cost")}: {route_result["total_cost"]}')
            if "distance" in route_result:
                st.write(f'{t("route_distance")}: {route_result["distance"]} {t("meters")}')
        else:
            st.warning(route_result.get("message", t("no_route")))


# ======================================================================
# 7. AR navigation (logic from ar.py)
# ======================================================================
def render_ar() -> None:
    try:
        from classes.ar_manger import ARManager
        from classes.corridor_crowd import CrowdManager
        from classes.Route_Manager import RouteManager
    except ImportError as e:
        st.error(t("missing_classes", name=str(e)))
        return

    st.markdown(
        f'<h2 class="camera-title">{t("ar_title")}</h2><p class="camera-description">{t("ar_desc")}</p>',
        unsafe_allow_html=True,
    )

    try:
        crowd_manager = CrowdManager()
        route_manager = RouteManager(crowd_manager)
    except FileNotFoundError as e:
        st.error(t("missing_data", name=e.filename or str(e)))
        return

    if route_manager.graph.number_of_nodes() == 0:
        route_manager.build_graph()
    if route_manager.graph.number_of_nodes() == 0:
        st.error(t("no_locations"))
        return

    location_ids = list(route_manager.graph.nodes)
    current_location = st.query_params.get("at", "TP_ENT")
    if current_location not in location_ids:
        current_location = location_ids[0]

    col1, col2 = st.columns(2)
    with col1:
        start = st.selectbox(t("you_are_at"), location_ids, index=location_ids.index(current_location),
                             format_func=lambda i: route_manager.graph.nodes[i]["name"])
    with col2:
        destination_ids = [i for i in location_ids if i != start]
        goal = st.selectbox(t("destination_label"), destination_ids,
                            index=destination_ids.index("SA_EXT") if "SA_EXT" in destination_ids else 0,
                            format_func=lambda i: route_manager.graph.nodes[i]["name"])

    st.divider()

    result = None
    if st.button(t("find_route"), key="ar_find", type="primary", use_container_width=True):
        result = route_manager.find_route(start, goal)
        if not result.get("route"):
            st.error(result.get("message", t("no_route")))
        else:
            st.session_state["ar_route"] = result["route"]
            st.session_state["ar_total_cost"] = result.get("total_cost")
            st.session_state["ar_destination"] = goal
            st.session_state["ar_start"] = start

    if "ar_route" in st.session_state:
        path = st.session_state["ar_route"]

        if st.session_state["ar_start"] != start or st.session_state["ar_destination"] != goal:
            st.session_state.pop("ar_route", None)
            st.rerun()
        else:
            st.success(t("route_found"))
            route_names = [route_manager.graph.nodes[i]["name"] for i in path]
            st.markdown(f'### {t("recommended_route")}')
            st.write(" → ".join(route_names))

            route_distance = 0
            for i in range(len(path) - 1):
                edge_data = route_manager.graph[path[i]][path[i + 1]]
                route_distance += float(edge_data.get("distance", edge_data.get("distance_m", 0)))

            col1, col2 = st.columns(2)
            with col1:
                st.metric(t("route_distance"), f"{route_distance:.1f} {t('meters')}")
            with col2:
                cost = st.session_state.get("ar_total_cost")
                st.metric(t("total_route_cost"), f"{cost:.1f}" if cost is not None else "—")

            st.divider()

            if len(path) > 1:
                current_id, next_id = path[0], path[1]
                next_data = route_manager.graph.nodes[next_id]
                destination_data = route_manager.graph.nodes[goal]
                edge_data = route_manager.graph[current_id][next_id]
                next_distance = edge_data.get("distance", edge_data.get("distance_m", 0))

                st.markdown(f'### 📷 {t("ar_navigation")}')
                ARManager().camera_view(
                    target_bearing=0,
                    next_name=next_data["name"],
                    next_distance=next_distance,
                    destination=destination_data["name"],
                )
            else:
                st.success(t("arrived"))


# ======================================================================
# 8. Account (logic from account.py)
# ======================================================================
def logout_callback() -> None:
    st.session_state.logged_in = False
    st.session_state.current_user = None
    flash(t("logged_out"))
    st.session_state.page = "login"


def render_account() -> None:
    with st.container(key="account_card"):
        st.markdown(f'<h1 class="title title--start">{t("account")}</h1>', unsafe_allow_html=True)

        # Settings – language (available to guests too)
        st.markdown(f'<h2 class="account-h">{t("settings")}</h2>', unsafe_allow_html=True)
        language_selector("account_language")
        st.caption(f'{t("current_language")}: {t("language_names")}')

        if not st.session_state.logged_in:
            st.warning(t("login_required"))
            st.button(t("login"), key="account_login", type="primary", on_click=go, args=("login",))
            return

        username = st.session_state.current_user
        user = st.session_state.auth.users[username]

        st.divider()
        st.markdown(f'<h2 class="account-h">{t("account_information")}</h2>', unsafe_allow_html=True)
        rows = [(t("account_name"), user.get("name", username)),
                (t("username"), user["username"]),
                (t("email"), user["email"])]
        st.markdown("".join(
            f'<div class="account-info"><span>{label}</span><b dir="auto">{html.escape(str(value))}</b></div>'
            for label, value in rows), unsafe_allow_html=True)

        st.divider()
        st.markdown(f'<h2 class="account-h">{t("change_password")}</h2>', unsafe_allow_html=True)
        old_password = st.text_input(t("current_password"), type="password", key="old_password")
        new_password = st.text_input(t("new_password"), type="password", key="new_password",
                                     placeholder=t("password_hint"))

        if st.button(t("update_password"), key="update_pw", type="primary"):
            if not st.session_state.auth.login(username, old_password):
                st.error(t("incorrect_current_password"))
            elif len(new_password) < 8:
                st.error(t("password_length"))
            else:
                user["password"] = new_password
                st.success(t("password_updated"))

        st.divider()
        st.button(t("logout"), key="logout_btn", on_click=logout_callback)


# ======================================================================
# Router
# ======================================================================
page = st.session_state.page
inject_css(page)

message = st.session_state.pop("flash", None)
if message:
    st.toast(message)

# The floating bar is fixed on screen, so it is drawn first: if a page calls
# st.stop()/st.rerun() the bar is still there.
if page in DOCK_PAGES:
    render_dock(page)

if page == "splash":
    with st.container(key="splash_page"):
        render_splash()
elif page in ONBOARDING:
    with st.container(key="onb_page"):
        render_onboarding(page)
elif page == "welcome":
    render_welcome()
elif page == "login":
    render_login()
elif page == "signup":
    render_signup()
elif page == "verify_email":
    render_verify_email()
elif page == "account_created":
    render_account_created()
elif page == "forgot":
    render_forgot()
elif page == "reset_code":
    render_reset_code()
elif page == "reset_new":
    render_reset_new()
elif page == "reset_done":
    render_reset_done()
elif page == "home":
    render_home()
elif page == "chat":
    render_chat()
elif page == "map":
    render_map()
elif page == "ar":
    render_ar()
elif page == "account":
    render_account()
else:
    st.session_state.page = "splash"
    st.rerun()
