import html
import streamlit.components.v1 as components


class ARManager:

    def camera_view(
        self,
        target_bearing=0,
        next_name="Main Corridor",
        next_distance=20,
        destination="Destination",
        north_offset=0
    ):

        destination = html.escape(str(destination))
        next_name = html.escape(str(next_name))
        next_distance = html.escape(str(next_distance))

        html_code = """
        <!DOCTYPE html>
        <html>

        <head>

            <meta name="viewport"
                  content="width=device-width, initial-scale=1.0">

            <style>

                * {
                    box-sizing: border-box;
                }

                body {
                    margin: 0;
                    padding: 10px;
                    background: #F5F7F4;
                    font-family: Arial, sans-serif;
                    color: #173D32;
                }

                .header {
                    font-size: 25px;
                    font-weight: bold;
                    margin-bottom: 8px;
                }

                .subtitle {
                    color: #68776F;
                    font-size: 14px;
                    margin-bottom: 15px;
                }

                .info-card {
                    background: white;
                    border-radius: 14px;
                    padding: 16px;
                    margin-bottom: 15px;
                    border: 1px solid #E1E9E3;
                }

                .label {
                    font-size: 12px;
                    color: #658273;
                    font-weight: bold;
                    margin-bottom: 5px;
                }

                .value {
                    font-size: 18px;
                    font-weight: bold;
                    margin-bottom: 12px;
                    color: #173D32;
                }

                .camera-container {
                    position: relative;
                    width: 100%;
                    height: 430px;
                    background: #17231D;
                    border-radius: 16px;
                    overflow: hidden;
                }

                video {
                    width: 100%;
                    height: 100%;
                    object-fit: cover;
                    display: none;
                }

                .placeholder {
                    position: absolute;
                    inset: 0;
                    display: flex;
                    flex-direction: column;
                    justify-content: center;
                    align-items: center;
                    color: white;
                    text-align: center;
                    gap: 12px;
                }

                .camera-icon {
                    font-size: 48px;
                }

                .guidance {
                    display: none;
                    position: absolute;
                    bottom: 20px;
                    left: 50%;
                    transform: translateX(-50%);
                    background: rgba(23, 61, 50, 0.92);
                    color: white;
                    padding: 15px 25px;
                    border-radius: 15px;
                    text-align: center;
                    min-width: 180px;
                }

                .arrow {
                    display: block;
                    font-size: 65px;
                    line-height: 1.1;
                    color: #A8E6BE;
                }

                .direction-text {
                    font-size: 16px;
                    font-weight: bold;
                }

                .state-card {
                    background: white;
                    border: 1px solid #E1E9E3;
                    border-radius: 14px;
                    padding: 20px;
                    text-align: center;
                    margin-top: 15px;
                }

                .state-icon {
                    font-size: 35px;
                    margin-bottom: 8px;
                }

                .state-title {
                    font-size: 20px;
                    font-weight: bold;
                    margin-bottom: 8px;
                }

                .state-message {
                    color: #68776F;
                    font-size: 13px;
                    line-height: 1.6;
                    margin-bottom: 15px;
                }

                button {
                    background: #38765B;
                    color: white;
                    border: none;
                    padding: 14px 20px;
                    border-radius: 10px;
                    font-size: 15px;
                    font-weight: bold;
                    cursor: pointer;
                    width: 100%;
                    max-width: 300px;
                    margin: 5px;
                }

                button:disabled {
                    opacity: 0.6;
                    cursor: wait;
                }

                .stop-button {
                    background: #A83252;
                    display: none;
                }

                .status {
                    color: #38765B;
                    font-size: 12px;
                    margin-top: 10px;
                    overflow-wrap: anywhere;
                }

                @media (max-width: 600px) {

                    .camera-container {
                        height: 380px;
                    }

                    body {
                        padding: 5px;
                    }

                }

            </style>

        </head>

        <body>

            <div class="header">
                EXORA AR Navigation
            </div>

            <div class="subtitle">
                Follow the arrow to reach your destination.
            </div>

            <div class="info-card">

                <div class="label">
                    YOUR DESTINATION
                </div>

                <div class="value">
                    __DESTINATION__
                </div>

                <hr>

                <div class="label">
                    NEXT LOCATION
                </div>

                <div class="value">
                    __NEXT_NAME__
                </div>

                <div class="label">
                    DISTANCE
                </div>

                <div class="value">
                    __NEXT_DISTANCE__ meters
                </div>

            </div>

            <div class="camera-container">

                <video id="camera"
                       autoplay
                       playsinline
                       muted>
                </video>

                <div class="placeholder" id="placeholder">

                    <div class="camera-icon">📷</div>

                    <div>
                        Camera is ready
                    </div>

                    <div>
                        Press Start AR Navigation
                    </div>

                </div>

                <div class="guidance" id="guidance">

                    <span class="arrow">↑</span>

                    <span class="direction-text">
                        Go Straight
                    </span>

                </div>

            </div>

            <div class="state-card">

                <div class="state-icon" id="stateIcon">
                    🧭
                </div>

                <div class="state-title" id="stateTitle">
                    AR Guidance
                </div>

                <div class="state-message" id="stateMessage">
                    Start navigation to activate your camera.
                </div>

                <button id="startButton">
                    Start AR Navigation
                </button>

                <button id="stopButton" class="stop-button">
                    Stop Navigation
                </button>

                <div class="status" id="status"></div>

            </div>


            <script>

                const video = document.getElementById("camera");

                const placeholder =
                    document.getElementById("placeholder");

                const guidance =
                    document.getElementById("guidance");

                const startButton =
                    document.getElementById("startButton");

                const stopButton =
                    document.getElementById("stopButton");

                const stateIcon =
                    document.getElementById("stateIcon");

                const stateTitle =
                    document.getElementById("stateTitle");

                const stateMessage =
                    document.getElementById("stateMessage");

                const status =
                    document.getElementById("status");

                let cameraStream = null;


                function showState(title, icon, message) {

                    stateTitle.textContent = title;
                    stateIcon.textContent = icon;
                    stateMessage.textContent = message;

                }


                async function startNavigation() {

                    if (
                        !navigator.mediaDevices ||
                        !navigator.mediaDevices.getUserMedia
                    ) {

                        showState(
                            "Camera Not Supported",
                            "⚠️",
                            "Open this page using HTTPS in a supported browser."
                        );

                        status.textContent =
                            "Camera access is unavailable.";

                        return;

                    }

                    try {

                        startButton.disabled = true;

                        showState(
                            "Starting Camera",
                            "📷",
                            "Please allow camera access."
                        );

                        status.textContent =
                            "Requesting camera permission...";


                        cameraStream =
                            await navigator.mediaDevices.getUserMedia({

                                video: {
                                    facingMode: {
                                        ideal: "environment"
                                    }
                                },

                                audio: false

                            });


                        video.srcObject = cameraStream;

                        video.style.display = "block";

                        await video.play();

                        placeholder.style.display = "none";

                        guidance.style.display = "block";

                        showState(
                            "AR Navigation Active",
                            "🧭",
                            "Follow the arrow to reach your next location."
                        );

                        status.textContent =
                            "Camera is active.";

                        startButton.style.display = "none";

                        stopButton.style.display = "inline-block";


                    } catch (error) {

                        console.error("Camera Error:", error);

                        stopCamera();

                        showState(
                            "Unable to Start Camera",
                            "⚠️",
                            error.name + ": " + error.message
                        );

                        status.textContent =
                            "Check your browser camera permissions.";

                    } finally {

                        startButton.disabled = false;

                    }

                }


                function stopCamera() {

                    if (cameraStream) {

                        cameraStream.getTracks().forEach(track => {
                            track.stop();
                        });

                        cameraStream = null;

                    }

                    video.pause();

                    video.srcObject = null;

                    video.style.display = "none";

                    placeholder.style.display = "flex";

                    guidance.style.display = "none";

                    startButton.style.display = "inline-block";

                    stopButton.style.display = "none";

                }


                startButton.addEventListener(
                    "click",
                    startNavigation
                );


                stopButton.addEventListener(
                    "click",
                    () => {

                        stopCamera();

                        showState(
                            "Navigation Stopped",
                            "🧭",
                            "You can start navigation again."
                        );

                        status.textContent = "Camera stopped.";

                    }
                );

            </script>

        </body>

        </html>
        """

        html_code = (
            html_code
            .replace("__DESTINATION__", destination)
            .replace("__NEXT_NAME__", next_name)
            .replace("__NEXT_DISTANCE__", next_distance)
        )

        components.html(
            html_code,
            height=850,
            scrolling=True
        )